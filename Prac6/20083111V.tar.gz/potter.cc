// Pablo Antonio Bernabeu Cartagena 20083111V

#include<iostream>
#include<fstream>
#include<cstring>
#include<vector>
#include<stdlib.h>
#include<limits>
using namespace std;

const int SENTINEL = -1;

int convertir_a_numero(char cadena){
  int s = cadena-48;
  return s;
}

void leerFichero(ifstream &fichero, string &file, int &n, int &T, vector<int> &t, vector<int> &v, vector<int> &m){

  if(fichero.is_open()){
    string cadena="";
    int i=0;

    fichero >> n;
    fichero >> T;

    while(getline(fichero, cadena)){

      if(i==0){

      }
      if(i==1){
        for(long unsigned int j=0; j<cadena.size(); j = j + 2){
          char c = cadena[j];
          t.push_back(convertir_a_numero(c));
        }
      }

      if(i==2){
        for(long unsigned int j=0; j<cadena.size(); j = j + 2){
          char c = cadena[j];
          v.push_back(convertir_a_numero(c));
        }
      }
      if(i==3){
        for(long unsigned int j=0; j<cadena.size(); j = j + 2){
          char c = cadena[j];
          m.push_back(convertir_a_numero(c));
        }
      }

      i++;
    }

    fichero.close();

  }
  else{
    cerr<<"ERROR: cant´t open file: "<<file<<"."<<endl;
    exit(0);
  }

}

int recursivoSinAlmacen(int n, int T, vector<int> &t, vector<int> &v){

  if(n==0 || T==0){
    return 0;
  }

  double s1 = recursivoSinAlmacen(n-1, T, t, v);
  double s2 = 0;


  if(t[n-1] <= T){
    s2 = v[n-1] + recursivoSinAlmacen(n-1, T-t[n-1], t, v);
  }

  return max(s1, s2);
}

int recursivoConAlmacen2(vector<vector<double>> &M, vector<int> &v, vector<int> &t, int n, int T){
  if(M[n][T]!=SENTINEL) return M[n][T];

  if(n==0) return M[n][T] = 0.0;

  double s1 = recursivoConAlmacen2(M, v, t, n-1, T);
  double s2 = 0;

  if(t[n-1] <= T){
    s2 = v[n-1] + recursivoConAlmacen2(M, v, t, n-1, T-t[n-1]);
  }

  return M[n][T] = max(s1, s2);

}

int recursivoConAlmacen1(vector<int> &t, vector<int> &v,  int n, int T){
  vector<vector<double>> M(n+1, vector<double>(T+1, SENTINEL));
  return recursivoConAlmacen2(M, v, t, n, T);
}



int main(int argc, char *argv[]){

  string file="";
  bool tOption=false;
  bool ignoreOption=true;

  for(int i=1; i<argc; i++){
    if(strcmp(argv[i], "--ignore-naive")==0){
      ignoreOption=false;
    }
  }


  // Gestión de argumentos
  for(int i=1; i<argc; i++){
    if(strcmp(argv[i], "-f")==0){
      if(i<argc-1){
        i++;
        file=argv[i];

        // Si se encuentra la opcion '-f' se procede a leer el fichero.

        int n=0, T=0;
        vector<int> t;
        vector<int> v;
        vector<int> m;

        vector<int> vMejor;
        vector<int> tiemposMejor;

        ifstream fichero(file);
        leerFichero(fichero, file, n, T, t, v, m);


        for(long unsigned int j=0; j<m.size(); j++){  // Cambiamos la matriz
          for(int k=0; k<m[j]; k++){
            vMejor.push_back(v[j]);
          }
        }

        for(long unsigned int j=0; j<m.size(); j++){
          for(int k=0; k<m[j]; k++){
            tiemposMejor.push_back(t[j]);
          }
        }

        int nMejor = vMejor.size();

        if(tOption && ignoreOption){

          cout<<recursivoSinAlmacen(nMejor, T, tiemposMejor, vMejor)<<" ";
          cout<<recursivoConAlmacen1(tiemposMejor, vMejor, nMejor, T);
          cout<<" ?";
          cout<<" ?"<<endl;
          cout<<"?"<<endl;
          cout<<"?"<<endl;
          cout<<"Memoization matrix: "<<endl;
          cout<<"?"<<endl;
          cout<<"Iterative matrix: "<<endl;
          cout<<"?"<<endl;

          cout<<endl;

        }
        if(tOption && !ignoreOption){

          cout<<recursivoConAlmacen1(tiemposMejor, vMejor, nMejor, T);
          cout<<" ?";
          cout<<" ?"<<endl;
          cout<<"?"<<endl;
          cout<<"?"<<endl;
          cout<<"Memoization matrix: "<<endl;
          cout<<"?"<<endl;
          cout<<"Iterative matrix: "<<endl;
          cout<<"?"<<endl;

          cout<<endl;

        }
        if(!tOption){

          cout<<recursivoConAlmacen1(tiemposMejor, vMejor, nMejor, T);
          cout<<" ?";
          cout<<" ?"<<endl;
          cout<<"?"<<endl;
          cout<<"?"<<endl;

          cout<<endl;

        }



        exit(1);
      }
      else{
        cerr<<"ERROR: missing filename."<<endl;
        exit(0);
      }
    }
    else if(strcmp(argv[i], "--ignore-naive")==0 || strcmp(argv[i], "-t")==0 || strcmp(argv[i], "-f")==0){
      if(strcmp(argv[i], "--ignore-naive")==0){
        ignoreOption=false;
      }
      if(strcmp(argv[i], "-t")==0){
        tOption=true;
      }
    }
    else{
      cerr<<"ERROR: unknown option "<< argv[i] <<"."<<endl;
      cerr<<"Usage: "<<endl;
      cerr<<"potter [-t] [--ignore-naive] -f file"<<endl;
      exit(0);
    }
  }

  return 0;
}
